"""
Phase 1 パッチ: config.py への追加内容
─────────────────────────────────────
config.py の末尾（CHART_COLORS の後）に以下を追記してください。
"""

# ──────────────────────────────
# v1.8: 前日比アラート閾値
# ──────────────────────────────
DOD_THRESHOLDS = {
    "inpatient": {
        "high": 15,   # |delta| >= 15人 → severity=high
        "medium": 8,  # |delta| >= 8人  → severity=medium
    },
    "new_admission": {
        "high": 10,
        "medium": 5,
    },
    "surgery": {
        "high": 3,
        "medium": 2,
    },
}
