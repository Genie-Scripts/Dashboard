"""
Phase 1-3 パッチ: generate_html.py への変更差分
───────────────────────────────────────────────

以下の3箇所を修正します。

━━━ 変更1: _build_kpi_and_rankings() に DOD アラート + ヘッドライン生成を追加 ━━━
"""

# ── 変更1: _build_kpi_and_rankings() を以下に差し替え ──

def _build_kpi_and_rankings(adm, surg, targets, surg_targets, base_date, sort_by, all_depts):
    """KPI・全ランキング・ヘッドライン・DODアラートを一括算出して返す"""
    kpi       = build_kpi_summary(adm, surg, base_date, targets, surg_targets)
    rank_inp  = build_dept_ranking(adm, base_date, targets, "inpatient",     sort_by)
    rank_nadm = build_dept_ranking(adm, base_date, targets, "new_admission", sort_by)
    rank_surg = build_surgery_ranking(surg, base_date, surg_targets, sort_by)
    rank_wi   = build_ward_ranking(adm, base_date, targets, "inpatient",     sort_by)
    rank_wn   = build_ward_ranking(adm, base_date, targets, "new_admission", sort_by)
    # 新ランキング
    doc_watch = build_doctor_watch_ranking(adm, surg, base_date, targets, surg_targets)
    doc_gap   = build_doctor_gap_ranking(adm, surg, base_date, targets, surg_targets)
    nur_watch = build_nurse_watch_ranking(adm, base_date, targets)
    nur_load  = build_nurse_load_ranking(adm, base_date)

    # ★ v1.8: ヘッドライン生成
    try:
        from app.lib.html_builder import build_headline
        headline = build_headline(kpi, watch_rank=doc_watch, gap_rank=doc_gap)
    except Exception as e:
        log(f"ヘッドライン生成スキップ: {e}", "warn")
        headline = None

    # ★ v1.8: 前日比アラート生成
    try:
        from app.lib.metrics import build_day_over_day_alerts
        dod_doctor = build_day_over_day_alerts(
            adm, surg, base_date, targets, surg_targets, role="doctor", max_alerts=4)
        dod_nurse  = build_day_over_day_alerts(
            adm, surg, base_date, targets, surg_targets, role="nurse", max_alerts=3)
    except Exception as e:
        log(f"前日比アラート生成スキップ: {e}", "warn")
        dod_doctor = []
        dod_nurse  = []

    return {
        "kpi": kpi,
        "rank_inp": rank_inp, "rank_nadm": rank_nadm, "rank_surg": rank_surg,
        "rank_wi": rank_wi, "rank_wn": rank_wn,
        "doc_watch": doc_watch, "doc_gap": doc_gap,
        "nur_watch": nur_watch, "nur_load": nur_load,
        # ★ v1.8 追加
        "headline":    headline,
        "dod_doctor":  dod_doctor,
        "dod_nurse":   dod_nurse,
    }


"""
━━━ 変更2: _generate_doctor() に headline / dod_alerts を追加 ━━━
既存の _generate_doctor() を以下に差し替え
"""

def _generate_doctor(ranks, chart_json, doctor_chart_json, all_depts, env, out_path) -> "Path":
    """doctor.html 生成（v1.8: headline + dod_alerts 追加）"""
    from app.lib.html_builder import build_doctor_context
    ctx  = build_doctor_context(
        kpi=ranks["kpi"],
        dept_ranking_inp=ranks["rank_inp"], dept_ranking_nadm=ranks["rank_nadm"],
        surgery_ranking=ranks["rank_surg"],
        doctor_watch_rank=ranks["doc_watch"],
        doctor_gap_rank=ranks["doc_gap"],
        chart_data_json=chart_json,
        doctor_chart_json=doctor_chart_json,
        all_depts=all_depts,
        generated_at=datetime.now(),
    )
    # ★ v1.8: ヘッドライン・前日比アラート
    ctx["headline"]   = ranks.get("headline")
    ctx["dod_alerts"] = ranks.get("dod_doctor", [])

    out_path.parent.mkdir(parents=True, exist_ok=True)
    html = env.get_template("doctor.html").render(**ctx)
    out_path.write_text(html, encoding="utf-8")
    log(f"doctor.html → {out_path}  ({out_path.stat().st_size // 1024} KB)", "ok")
    return out_path


"""
━━━ 変更3: _generate_portal() に headline / dod_alerts を追加 ━━━
既存の _generate_portal() を以下に差し替え
"""

def _generate_portal(kpi, base_date, generated_at,
                      admission_html_exists, inpatient_html_exists,
                      env, out_path,
                      operation_html_exists=False,
                      headline=None, dod_alerts=None) -> "Path":
    """portal.html 生成（v1.8: headline + dod_alerts 追加）"""
    from app.lib.html_builder import build_kpi_card_data

    cards = build_kpi_card_data(kpi)
    portal_kpis = [c for c in cards if c["id"] in ("inpatient", "new_admission_7d", "surgery")]

    ctx = {
        "generated_at":            generated_at.strftime("%Y/%m/%d %H:%M"),
        "base_date":               base_date.strftime("%Y/%m/%d"),
        "base_date_raw":           base_date.strftime("%Y-%m-%d"),
        "portal_kpis":             portal_kpis,
        "admission_html_exists":   admission_html_exists,
        "inpatient_html_exists":   inpatient_html_exists,
        "operation_html_exists":   operation_html_exists,
        # ★ v1.8
        "headline":   headline,
        "dod_alerts": dod_alerts or [],
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    html = env.get_template("portal.html").render(**ctx)
    out_path.write_text(html, encoding="utf-8")
    log(f"portal.html → {out_path}  ({out_path.stat().st_size // 1024} KB)", "ok")
    return out_path


"""
━━━ 変更4: _generate_nurse() に dod_alerts を追加 ━━━
既存の _generate_nurse() の ctx に以下を追加:
    ctx["dod_alerts"] = ranks.get("dod_nurse", [])
"""


"""
━━━ 変更5: generate() 内の _generate_portal() 呼び出しに headline / dod_alerts を追加 ━━━
既存の呼び出しを以下に変更:

    portal_path = _generate_portal(
        kpi=ranks["kpi"],
        base_date=base_date,
        generated_at=datetime.now(),
        admission_html_exists=admission_exists,
        inpatient_html_exists=inpatient_exists,
        operation_html_exists=operation_exists,
        env=env,
        out_path=out_dir / "portal.html",
        headline=ranks.get("headline"),          # ★ v1.8 追加
        dod_alerts=ranks.get("dod_doctor", []),  # ★ v1.8 追加
    )
"""
