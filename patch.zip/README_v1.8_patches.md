# v1.8 パッチ適用手順書
# ═══════════════════════════════════════════════

## 概要
3つの機能を段階的に適用します。各Phase完了時に `make build-fast` で動作確認できます。

---

## Phase 1: 前日比アラート

### Step 1-1: config.py
ファイル末尾（CHART_COLORS の後）に DOD_THRESHOLDS を追加。
→ `phase1_config_patch.py` の内容を追記

### Step 1-2: metrics.py
1. ファイル先頭の import に追加:
   ```python
   from .config import DOD_THRESHOLDS
   ```
2. ファイル末尾（build_kpi_summary の後）に関数を追加:
   - `build_day_over_day_alerts()`
   - `_add_dept_alerts()`
   - `_add_ward_alerts()`
→ `phase1_metrics_patch.py` の内容を追記

### Step 1-3: generate_html.py
1. `_build_kpi_and_rankings()` を差し替え（headline + dod 生成を追加）
2. `_generate_portal()` に headline / dod_alerts 引数を追加
3. `_generate_doctor()` の ctx に headline / dod_alerts を追加
4. `_generate_nurse()` の ctx に dod_alerts を追加
5. `generate()` 内の `_generate_portal()` 呼び出しに引数追加
→ `phase1_2_generate_html_patch.py` 参照

### Step 1-4: portal.html テンプレート
1. CSS に `.dod-row` / `.dod-card` スタイルを追加
2. hero直後・KPIサマリー直前に dod_alerts セクションを挿入
→ `phase1_2_portal_template_patch.html` の DOD 部分を適用

### Step 1-5: doctor.html テンプレート
1. CSS に `.dod-row` / `.dod-card` スタイルを追加
2. KPIカード行の直前に dod_alerts セクションを挿入
→ `phase3_doctor_template_patch.html` の DOD 部分を適用

### Step 1-6: nurse.html テンプレート
1. 同様に CSS + dod_alerts セクションを追加（病棟別データ）

### 動作確認
```bash
make build-fast
# portal.html / doctor.html / nurse.html にアラートカードが表示されることを確認
```

---

## Phase 2: ヘッドライン

### Step 2-1: html_builder.py
build_insights() の直後に関数を追加:
- `build_headline()`
- `_extract_highlights()`
→ `phase2_headline_patch.py` の内容を追記

### Step 2-2: portal.html テンプレート
1. CSS に `.headline-banner` スタイルを追加
2. hero直後に headline-banner セクションを挿入（dod_alerts の直前）
→ `phase1_2_portal_template_patch.html` の headline 部分を適用

### Step 2-3: doctor.html テンプレート
1. CSS に `.headline-banner` スタイルを追加
2. 既存の `role-brief` セクション（`<div class="role-brief" id="roleBrief">` ブロック）を削除
3. 同じ位置に headline-banner を挿入
→ `phase3_doctor_template_patch.html` の headline 部分を適用

### 動作確認
```bash
make build-fast
# portal.html / doctor.html の最上部にヘッドラインメッセージが表示されることを確認
```

---

## Phase 3: doctor.html UI階層整理

### Step 3-1: doctor.html テンプレート
1. CSS に `.section-collapsible` / `.section-toggle` スタイルを追加
2. 既存の ROW B（目標差分ランキング左右）/ ROW C（ウォーターフォール + バブル）/ ROW D（ヒートマップ）を `<div class="section-collapsible" id="detailSection">` でラップ
3. 既存の ROW E（在院・新入院推移）/ ROW F（全麻推移）を `<div class="section-collapsible" id="chartSection">` でラップ
4. `toggleSection()` JavaScript関数を追加
→ `phase3_doctor_template_patch.html` 参照

### 注意点
- 折りたたみを開いた際にPlotlyグラフが正しくリサイズされるよう、
  `Plotly.Plots.resize()` を `setTimeout` で呼び出しています
- ROW A（累積進捗）と ROW A2（要注視ランキング）は折りたたみ外に残します

### 動作確認
```bash
make
# doctor.html で:
# - ファーストビューにヘッドライン + アラート + KPI + 累積進捗 + 要注視ランキング
# - 「📊 詳細分析を表示」ボタンで ROW B〜D が展開/折りたたみ
# - 「📈 推移チャートを表示」ボタンで ROW E〜F が展開/折りたたみ
```

---

## 最終確認
全Phase適用後:
```bash
make             # フルビルド
make serve       # ローカルサーバー起動
# ブラウザで portal.html を開き以下を確認:
# 1. ヘッドラインバナー（🟢/🟡/🔴 + メッセージ）
# 2. 前日比アラートカード（変化量が大きい科のみ表示）
# 3. KPIサマリーカード（既存、変更なし）
# doctor.html を開き以下を確認:
# 4. ヘッドラインバナー（portal と同じメッセージ）
# 5. 前日比アラートカード
# 6. KPIカード + 累積進捗 + 要注視ランキング（常時表示）
# 7. 詳細分析 / 推移チャート（折りたたみ、クリックで展開）
```

---

## 仕様書更新
全確認完了後、診療ダッシュボード_システム仕様書を v1.8 に更新。
改訂履歴に以下を追記:
| 1.8 | 2026-04-01 | ヘッドライン自動生成 / 前日比アラート / doctor.html UI階層整理（詳細折りたたみ） |
