"""
Phase 1 パッチ: metrics.py への追加内容
──────────────────────────────────────
metrics.py の末尾（build_kpi_summary の後）に以下を追記してください。
import 追加: from .config import DOD_THRESHOLDS (ファイル先頭)
"""


def build_day_over_day_alerts(adm: pd.DataFrame,
                               surg: pd.DataFrame,
                               base_date: pd.Timestamp,
                               targets: dict,
                               surg_targets: dict,
                               role: str = "doctor",
                               max_alerts: int = 4) -> list:
    """
    前日比アラート生成（v1.8 機能B）。
    
    base_date と base_date-1日 の日次集計を比較し、
    変化量が大きい科/病棟を検出してアラートリストを返す。
    
    Args:
        role: "doctor" → 診療科別、"nurse" → 病棟別
        max_alerts: 返すアラートの最大件数
    
    Returns:
        list[dict] — 変化量の絶対値が大きい順にソート
    """
    from .config import DOD_THRESHOLDS, WARD_NAMES

    prev_date = base_date - pd.Timedelta(days=1)

    # 前日のデータが存在するか確認
    if prev_date < adm["日付"].min():
        return []

    # ── 日次集計（当日・前日）──
    inp_today = daily_inpatient(adm, base_date)
    inp_prev  = daily_inpatient(adm, prev_date)
    nadm_today = daily_new_admission(adm, base_date)
    nadm_prev  = daily_new_admission(adm, prev_date)

    alerts = []

    if role == "doctor":
        # 診療科別: 在院・新入院
        _add_dept_alerts(alerts, inp_today["by_dept"], inp_prev["by_dept"],
                         "inpatient", "在院患者数", DOD_THRESHOLDS["inpatient"])
        _add_dept_alerts(alerts, nadm_today["by_dept"], nadm_prev["by_dept"],
                         "new_admission", "新入院", DOD_THRESHOLDS["new_admission"])

        # 全麻（当日 vs 前日の診療科別件数）
        surg_today_ga = (surg[(surg["手術実施日"] == base_date) & surg["全麻"]]
                         .groupby("実施診療科").size().to_dict())
        surg_prev_ga  = (surg[(surg["手術実施日"] == prev_date) & surg["全麻"]]
                         .groupby("実施診療科").size().to_dict())
        _add_dept_alerts(alerts, surg_today_ga, surg_prev_ga,
                         "surgery", "全身麻酔", DOD_THRESHOLDS["surgery"])

    elif role == "nurse":
        # 病棟別: 在院・新入院
        _add_ward_alerts(alerts, inp_today["by_ward"], inp_prev["by_ward"],
                         "inpatient", "在院患者数", DOD_THRESHOLDS["inpatient"],
                         WARD_NAMES)
        _add_ward_alerts(alerts, nadm_today["by_ward"], nadm_prev["by_ward"],
                         "new_admission", "新入院", DOD_THRESHOLDS["new_admission"],
                         WARD_NAMES)

    # |delta| 降順でソート → 上位 N 件
    alerts.sort(key=lambda a: abs(a["delta"]), reverse=True)
    return alerts[:max_alerts]


def _add_dept_alerts(alerts: list,
                      today_map: dict, prev_map: dict,
                      metric: str, metric_label: str,
                      thresholds: dict):
    """診療科別の前日比アラートを alerts リストに追加"""
    all_keys = set(today_map.keys()) | set(prev_map.keys())
    for dept in all_keys:
        today_val = today_map.get(dept, 0)
        prev_val  = prev_map.get(dept, 0)
        delta = today_val - prev_val
        abs_delta = abs(delta)

        if abs_delta < thresholds["medium"]:
            continue

        severity = "high" if abs_delta >= thresholds["high"] else "medium"
        direction = "up" if delta > 0 else "down"
        unit = "件" if metric == "surgery" else "人"

        sign = "+" if delta > 0 else ""
        alerts.append({
            "entity_name":    dept,
            "metric":         metric,
            "metric_label":   metric_label,
            "today_value":    today_val,
            "yesterday_value": prev_val,
            "delta":          delta,
            "delta_pct":      round(delta / prev_val * 100, 1) if prev_val != 0 else None,
            "direction":      direction,
            "severity":       severity,
            "message":        f"{metric_label}が前日比{sign}{delta}{unit}",
        })


def _add_ward_alerts(alerts: list,
                      today_map: dict, prev_map: dict,
                      metric: str, metric_label: str,
                      thresholds: dict,
                      ward_names: dict):
    """病棟別の前日比アラートを alerts リストに追加"""
    from .config import WARD_HIDDEN
    all_keys = set(today_map.keys()) | set(prev_map.keys())
    for wcode in all_keys:
        if wcode in WARD_HIDDEN:
            continue
        today_val = today_map.get(wcode, 0)
        prev_val  = prev_map.get(wcode, 0)
        delta = today_val - prev_val
        abs_delta = abs(delta)

        if abs_delta < thresholds["medium"]:
            continue

        severity = "high" if abs_delta >= thresholds["high"] else "medium"
        direction = "up" if delta > 0 else "down"
        unit = "人"

        sign = "+" if delta > 0 else ""
        alerts.append({
            "entity_name":    ward_names.get(wcode, wcode),
            "metric":         metric,
            "metric_label":   metric_label,
            "today_value":    today_val,
            "yesterday_value": prev_val,
            "delta":          delta,
            "delta_pct":      round(delta / prev_val * 100, 1) if prev_val != 0 else None,
            "direction":      direction,
            "severity":       severity,
            "message":        f"{metric_label}が前日比{sign}{delta}{unit}",
        })
