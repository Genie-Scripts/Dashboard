"""
Phase 2 パッチ: html_builder.py への追加内容
────────────────────────────────────────────
html_builder.py の build_insights() の直後に以下を追記してください。
"""


def build_headline(kpi: dict,
                    watch_rank: list = None,
                    gap_rank: dict = None) -> dict:
    """
    今日のヘッドライン自動生成（v1.8 機能A）。

    KPI達成状況を自然言語メッセージで要約し、
    ポータル / 医師ダッシュボードのファーストビューに表示する。

    Args:
        kpi:         build_kpi_summary() の出力
        watch_rank:  build_doctor_watch_ranking() の出力（省略可）
        gap_rank:    build_doctor_gap_ranking() の出力（省略可）

    Returns:
        {overall_status, icon, main_message, detail_message, highlights}
    """
    import pandas as _pd

    inp  = kpi["inpatient"]
    nadm = kpi["new_admission"]
    surg = kpi["surgery"]

    inp_ach  = inp.get("achievement") or 0
    nadm_ach = nadm.get("rolling7_progress") or nadm.get("weekly_progress") or 0
    surg_ach = surg.get("ga_achievement") or 0

    # ── ハイライト科の抽出 ──
    highlights = _extract_highlights(gap_rank) if gap_rank else []

    # ── ワースト科の文字列生成 ──
    def _worst_text(gap_list, unit="人"):
        """gap ランキングから不足上位2科を文字列化"""
        negatives = [r for r in gap_list if (r.get("gap") or 0) < 0]
        negatives.sort(key=lambda r: r.get("gap", 0))
        if not negatives:
            return ""
        parts = []
        for r in negatives[:2]:
            parts.append(f"{r['name']}（{r['gap']:+.0f}{unit}）")
        return "。" + "と".join(parts) + "が不足の主因です"

    # ── ベスト科の文字列生成 ──
    def _best_text(gap_list, unit="人"):
        positives = [r for r in gap_list if (r.get("gap") or 0) > 0]
        positives.sort(key=lambda r: -(r.get("gap") or 0))
        if not positives:
            return ""
        r = positives[0]
        return f"。特に{r['name']}が好調（{r['gap']:+.0f}{unit}）です"

    # ── gap ランキングからの補助テキスト ──
    adm_gaps  = gap_rank.get("admission_gap", []) if gap_rank else []
    surg_gaps = gap_rank.get("surgery_gap", [])   if gap_rank else []

    # ── 達成率まとめ文字列 ──
    ach_summary = f"在院{inp_ach:.0f}%・新入院{nadm_ach:.0f}%・全麻{surg_ach:.0f}%"

    # ── メッセージ決定（優先順） ──
    # 新入院数値
    nadm_total  = nadm.get("rolling7_total") or nadm.get("weekly_total") or 0
    nadm_target = nadm.get("rolling7_target") or nadm.get("weekly_target") or 385

    # 全麻数値
    surg_avg    = surg.get("ga_rolling_avg") or 0
    surg_target = surg.get("ga_target") or 21

    # 在院数値
    inp_val    = inp.get("value", 0)
    inp_target = inp.get("target", 580)

    # 優先1: 新入院 < 90%
    if nadm_ach < 90:
        main  = "🔴 新入院が目標を大きく下回っています"
        detail = (f"直近7日 {nadm_total}人 / 目標{nadm_target}人"
                  f"（達成率{nadm_ach:.0f}%）"
                  f"{_worst_text(adm_gaps)}")
        overall = "ng"

    # 優先2: 全麻 < 90%
    elif surg_ach < 90:
        main  = "🔴 全身麻酔件数が目標を下回っています"
        detail = (f"直近7平日平均 {surg_avg}件 / 目標{surg_target}件"
                  f"（達成率{surg_ach:.0f}%）"
                  f"{_worst_text(surg_gaps, '件')}")
        overall = "ng"

    # 優先3: 在院 < 90%
    elif inp_ach < 90:
        main  = "🔴 在院患者数が目標を大きく下回っています"
        detail = (f"在院 {inp_val}人 / 目標{inp_target}人"
                  f"（達成率{inp_ach:.0f}%）")
        overall = "ng"

    # 優先4: いずれか < 95%
    elif min(inp_ach, nadm_ach, surg_ach) < 95:
        # どれが下回っているか特定
        below = []
        if nadm_ach < 95:
            below.append(f"新入院（{nadm_ach:.0f}%）")
        if surg_ach < 95:
            below.append(f"全麻（{surg_ach:.0f}%）")
        if inp_ach < 95:
            below.append(f"在院（{inp_ach:.0f}%）")
        main  = "🟡 一部KPIに注意が必要です"
        detail = f"{ach_summary}。{'・'.join(below)}が目標を下回っています"
        overall = "warn"

    # 優先5: 全部 >= 105%
    elif min(inp_ach, nadm_ach, surg_ach) >= 105:
        main  = "🟢 全KPIが目標を達成しています"
        detail = f"{ach_summary}{_best_text(adm_gaps)}"
        overall = "ok"

    # 優先6: 概ね目標水準
    else:
        main  = "🟢 KPIは概ね目標水準です"
        detail = f"{ach_summary}。大きな乖離はありません"
        overall = "ok"

    icons = {"ok": "🟢", "warn": "🟡", "ng": "🔴"}

    return {
        "overall_status": overall,
        "icon":           icons.get(overall, "🟢"),
        "main_message":   main,
        "detail_message":  detail,
        "highlights":     highlights,
    }


def _extract_highlights(gap_rank: dict, max_items: int = 3) -> list:
    """
    gap_rank から乖離が大きい科をピックアップ。
    不足側を優先し、max_items 件を返す。
    """
    items = []

    for metric_key, unit in [("admission_gap", "人"), ("surgery_gap", "件")]:
        for r in gap_rank.get(metric_key, []):
            gap = r.get("gap")
            if gap is None:
                continue
            items.append({
                "name":        r["name"],
                "type":        "admission" if "admission" in metric_key else "surgery",
                "delta":       gap,
                "achievement": r.get("achievement"),
                "status":      r.get("status", "neutral"),
            })

    # 不足側（gap < 0）を優先、次に超過側
    negatives = [i for i in items if i["delta"] < 0]
    positives = [i for i in items if i["delta"] > 0]
    negatives.sort(key=lambda x: x["delta"])
    positives.sort(key=lambda x: -x["delta"])

    return (negatives + positives)[:max_items]
